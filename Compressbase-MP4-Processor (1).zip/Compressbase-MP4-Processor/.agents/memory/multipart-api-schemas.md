---
name: Multipart API schemas
description: Compatibility rule for generated multipart upload contracts in this workspace
---

For multipart upload endpoints, describe the file part as a string with a clear multipart description when the generated server-side Zod package cannot compile browser `File`/`Blob` types; keep the actual request multipart and validate the bytes in the route.

**Why:** The current codegen path targets a Zod version where generated `zod.int()` and browser-only binary types can break the shared library typecheck. A documented string part preserves generated client FormData behavior while avoiding those compile-time dependencies.

**How to apply:** Re-run API codegen after schema changes, then run the shared library typecheck before building route or frontend code.

The API workflow may run with `artifacts/api-server` as its working directory rather than the workspace root, so worker files should be resolved relative to the bundled server directory with a small cwd fallback list.

**Why:** Building a path by blindly prefixing `process.cwd()` can duplicate `artifacts/api-server` and make the Python worker unreachable.

**How to apply:** Resolve runtime-adjacent scripts from `import.meta.dirname` first, then use cwd-based fallbacks only for local execution.