---
name: Large video uploads
description: Deployment requirement for chunked uploads and temporary video processing files
---

Chunked MP4 uploads are stored temporarily on the API instance while chunks are reassembled, processed, and downloaded. Publish this flow as a VM deployment; Autoscale can route separate chunk requests to different instances.

**Why:** The public Replit proxy rejected single upload requests around 32 MiB, while the API's 300 MiB limit was not the cause. Instance-local session state and temporary files are not shared across Autoscale instances.

**How to apply:** Keep chunk requests below the proxy limit, use temporary instance-local files only with VM, and clean the files after download or by TTL. Do not change the FFmpeg pipeline to address request-size limits.