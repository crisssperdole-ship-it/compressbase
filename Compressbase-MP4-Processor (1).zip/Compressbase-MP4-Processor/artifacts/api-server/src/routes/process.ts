import { Router, type IRouter, type Request, type Response } from "express";
import { randomUUID } from "node:crypto";
import { existsSync, promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";

const router: IRouter = Router();
const MAX_UPLOAD_BYTES = 300 * 1024 * 1024;
const UPLOAD_CHUNK_BYTES = 8 * 1024 * 1024;
const UPLOAD_SESSION_TTL_MS = 2 * 60 * 60 * 1000;
const allowedPresets = new Set([
  "ultrafast",
  "superfast",
  "veryfast",
  "faster",
  "fast",
  "medium",
  "slow",
]);
const allowedLevels = new Set(["3.1", "3.2", "4.0", "4.1", "4.2"]);

type UploadSession = {
  id: string;
  dir: string;
  chunksDir: string;
  sourcePath: string;
  outputPath: string;
  fileName: string;
  sizeBytes: number;
  fields: Record<string, string>;
  receivedBytes: number;
  nextChunkIndex: number;
  processing: boolean;
  updatedAt: number;
  result?: Record<string, unknown>;
};

const uploadSessions = new Map<string, UploadSession>();

const uploadSessionCleanup = setInterval(() => {
  const expiredBefore = Date.now() - UPLOAD_SESSION_TTL_MS;
  for (const session of uploadSessions.values()) {
    if (!session.processing && session.updatedAt < expiredBefore) {
      uploadSessions.delete(session.id);
      void fs.rm(session.dir, { recursive: true, force: true }).catch(() => undefined);
    }
  }
}, 15 * 60 * 1000);
uploadSessionCleanup.unref();

type MultipartPart = {
  name: string;
  filename?: string;
  contentType?: string;
  data: Buffer;
};

function parseMultipart(buffer: Buffer, contentType: string): MultipartPart[] {
  const match = contentType.match(/boundary="?([^";]+)"?/i);
  if (!match) {
    throw new Error("Missing multipart boundary.");
  }

  const delimiter = Buffer.from(`--${match[1]}`);
  const parts: MultipartPart[] = [];
  let cursor = buffer.indexOf(delimiter);

  while (cursor >= 0) {
    const partStart = cursor + delimiter.length;
    if (buffer.subarray(partStart, partStart + 2).toString() === "--") break;

    const headersStart =
      buffer.subarray(partStart, partStart + 2).toString() === "\r\n"
        ? partStart + 2
        : partStart;
    const headersEnd = buffer.indexOf(Buffer.from("\r\n\r\n"), headersStart);
    if (headersEnd < 0) break;

    const nextDelimiter = buffer.indexOf(delimiter, headersEnd + 4);
    if (nextDelimiter < 0) break;

    const rawHeaders = buffer
      .subarray(headersStart, headersEnd)
      .toString("latin1");
    const contentDisposition = rawHeaders.match(
      /content-disposition:\s*form-data;\s*([^]*?)(?:\r\n|$)/i,
    )?.[1];
    const name = contentDisposition?.match(/name="([^"]+)"/i)?.[1];
    if (!name) {
      cursor = nextDelimiter;
      continue;
    }

    const filename = contentDisposition?.match(/filename="([^"]*)"/i)?.[1];
    const contentTypeMatch = rawHeaders.match(/content-type:\s*([^\r\n]+)/i);
    parts.push({
      name,
      filename: filename || undefined,
      contentType: contentTypeMatch?.[1]?.trim(),
      data: buffer.subarray(headersEnd + 4, nextDelimiter - 2),
    });
    cursor = nextDelimiter;
  }

  return parts;
}

async function readRequest(
  req: Request,
  maxBytes = MAX_UPLOAD_BYTES,
  limitMessage = "The MP4 file is larger than the 300 MB limit.",
): Promise<Buffer> {
  const chunks: Buffer[] = [];
  let total = 0;

  for await (const chunk of req) {
    const data = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    total += data.length;
    if (total > maxBytes) {
      throw new Error(limitMessage);
    }
    chunks.push(data);
  }
  return Buffer.concat(chunks);
}

function uploadSettings(rawSettings: unknown): Record<string, string> {
  if (!rawSettings || typeof rawSettings !== "object" || Array.isArray(rawSettings)) {
    throw new Error("Invalid processing settings.");
  }
  const fields = Object.fromEntries(
    Object.entries(rawSettings).map(([key, value]) => {
      if (typeof value !== "string" && typeof value !== "number") {
        throw new Error("Invalid processing settings.");
      }
      return [key, String(value)];
    }),
  );
  if (fields.preset && !allowedPresets.has(fields.preset)) {
    throw new Error("Invalid encoding preset.");
  }
  if (fields.level && !allowedLevels.has(fields.level)) {
    throw new Error("Invalid H.264 level.");
  }
  if ((fields.comment ?? "").length > 200) {
    throw new Error("The comment is limited to 200 characters.");
  }
  numberField(fields.bitrate_multiplier, 1, 0.05, 2);
  numberField(fields.audio_bitrate1, 190, 32, 512);
  numberField(fields.audio_bitrate2, 215, 32, 512);
  return fields;
}

async function getUploadSession(id: string): Promise<UploadSession | undefined> {
  const session = uploadSessions.get(id);
  if (!session) return undefined;
  session.updatedAt = Date.now();
  return session;
}

async function removeUploadSession(session: UploadSession): Promise<void> {
  uploadSessions.delete(session.id);
  await fs.rm(session.dir, { recursive: true, force: true });
}

async function assembleUpload(session: UploadSession): Promise<void> {
  await fs.writeFile(session.sourcePath, Buffer.alloc(0));
  for (let index = 0; index < session.nextChunkIndex; index += 1) {
    const chunkPath = path.join(session.chunksDir, `${index}.part`);
    const chunk = await fs.readFile(chunkPath);
    await fs.appendFile(session.sourcePath, chunk);
  }
}

function numberField(
  value: string | undefined,
  fallback: number,
  min: number,
  max: number,
): number {
  if (value === undefined || value === "") return fallback;
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < min || parsed > max) {
    throw new Error("Invalid processing settings.");
  }
  return parsed;
}

function runWorker(
  inputPath: string,
  outputPath: string,
  fields: Record<string, string>,
): Promise<Record<string, unknown>> {
  const workerCandidates = [
    path.resolve(import.meta.dirname, "../compressbase/process_video.py"),
    path.resolve(process.cwd(), "compressbase/process_video.py"),
    path.resolve(
      process.cwd(),
      "artifacts/api-server/compressbase/process_video.py",
    ),
  ];
  const workerPath = workerCandidates.find((candidate) => existsSync(candidate));
  if (!workerPath) {
    throw new Error("The video processing worker is not installed.");
  }
  const args = [
    workerPath,
    "--input",
    inputPath,
    "--output",
    outputPath,
    "--bitrate-multiplier",
    String(numberField(fields.bitrate_multiplier, 1.0, 0.05, 2)),
    "--audio-bitrate1",
    String(numberField(fields.audio_bitrate1, 190, 32, 512)),
    "--audio-bitrate2",
    String(numberField(fields.audio_bitrate2, 215, 32, 512)),
    "--preset",
    fields.preset || "fast",
    "--level",
    fields.level || "4.2",
    "--comment",
    fields.comment || "Patched by video.optimizemethod",
  ];

  return new Promise((resolve, reject) => {
    const child = spawn("python3", args, { stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (chunk: Buffer) => {
      stdout += chunk.toString();
    });
    child.stderr.on("data", (chunk: Buffer) => {
      stderr += chunk.toString();
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code !== 0) {
        reject(
          new Error(
            stderr.trim() || `Video processing failed with exit code ${code}.`,
          ),
        );
        return;
      }
      try {
        resolve(JSON.parse(stdout.trim()) as Record<string, unknown>);
      } catch {
        reject(new Error("The processing result could not be read."));
      }
    });
  });
}

router.post("/process", async (req, res: Response) => {
  let workDir: string | undefined;
  try {
    const contentType = req.headers["content-type"] ?? "";
    if (!contentType.toLowerCase().startsWith("multipart/form-data")) {
      res.status(400).json({ error: "Upload the MP4 as multipart form-data." });
      return;
    }

    const body = await readRequest(req);
    const parts = parseMultipart(body, contentType);
    const filePart = parts.find((part) => part.name === "file");
    if (!filePart || !filePart.data.length) {
      res.status(400).json({ error: "Choose an MP4 file before processing." });
      return;
    }

    const filename = filePart.filename ?? "video.mp4";
    const fields = Object.fromEntries(
      parts
        .filter((part) => part.name !== "file")
        .map((part) => [part.name, part.data.toString("utf8")]),
    );
    if (
      !filename.toLowerCase().endsWith(".mp4") &&
      filePart.contentType !== "video/mp4"
    ) {
      res.status(400).json({ error: "Only MP4 video files are accepted." });
      return;
    }
    if (fields.preset && !allowedPresets.has(fields.preset)) {
      res.status(400).json({ error: "Invalid encoding preset." });
      return;
    }
    if (fields.level && !allowedLevels.has(fields.level)) {
      res.status(400).json({ error: "Invalid H.264 level." });
      return;
    }
    if ((fields.comment ?? "").length > 200) {
      res.status(400).json({ error: "The comment is limited to 200 characters." });
      return;
    }

    workDir = await fs.mkdtemp(path.join(os.tmpdir(), "compressbase-"));
    const inputPath = path.join(workDir, "source.mp4");
    const outputPath = path.join(workDir, "processed.mp4");
    await fs.writeFile(inputPath, filePart.data);
    const result = await runWorker(inputPath, outputPath, fields);
    const processed = await fs.readFile(outputPath);
    const stem = path.basename(filename, path.extname(filename));

    res.json({
      fileName: `${stem}_video.optimizemethod.mp4`,
      mimeType: "video/mp4",
      data: processed.toString("base64"),
      ...result,
    });
  } catch (error) {
    req.log.error({ err: error }, "Video processing failed");
    const message =
      error instanceof Error ? error.message : "Video processing failed.";
    res.status(message.includes("limit") ? 413 : 500).json({ error: message });
  } finally {
    if (workDir) {
      await fs.rm(workDir, { recursive: true, force: true }).catch(() => undefined);
    }
  }
});

router.post("/process/uploads", async (req, res: Response) => {
  let dir: string | undefined;
  try {
    const fileName =
      typeof req.body?.fileName === "string"
        ? path.basename(req.body.fileName).replace(/[\r\n"]/g, "_")
        : "";
    const sizeBytes = Number(req.body?.sizeBytes);
    const contentType =
      typeof req.body?.contentType === "string" ? req.body.contentType : "";
    if (!fileName || (!fileName.toLowerCase().endsWith(".mp4") && contentType !== "video/mp4")) {
      res.status(400).json({ error: "Only MP4 video files are accepted." });
      return;
    }
    if (!Number.isSafeInteger(sizeBytes) || sizeBytes < 1 || sizeBytes > MAX_UPLOAD_BYTES) {
      res.status(413).json({ error: "The MP4 file must be between 1 byte and 300 MB." });
      return;
    }

    const fields = uploadSettings(req.body?.settings);
    dir = await fs.mkdtemp(path.join(os.tmpdir(), "video-optimizemethod-upload-"));
    const id = randomUUID();
    const chunksDir = path.join(dir, "chunks");
    await fs.mkdir(chunksDir);
    const session: UploadSession = {
      id,
      dir,
      chunksDir,
      sourcePath: path.join(dir, "source.mp4"),
      outputPath: path.join(dir, "processed.mp4"),
      fileName,
      sizeBytes,
      fields,
      receivedBytes: 0,
      nextChunkIndex: 0,
      processing: false,
      updatedAt: Date.now(),
    };
    uploadSessions.set(id, session);
    dir = undefined;
    res.status(201).json({
      uploadId: id,
      chunkSizeBytes: UPLOAD_CHUNK_BYTES,
      chunkCount: Math.ceil(sizeBytes / UPLOAD_CHUNK_BYTES),
    });
  } catch (error) {
    if (dir) await fs.rm(dir, { recursive: true, force: true }).catch(() => undefined);
    const message = error instanceof Error ? error.message : "Could not start the upload.";
    res.status(400).json({ error: message });
  }
});

router.put(
  "/process/uploads/:uploadId/chunks/:chunkIndex",
  async (req, res: Response) => {
    try {
      const session = await getUploadSession(req.params.uploadId);
      if (!session) {
        res.status(404).json({ error: "Upload session not found. Start the upload again." });
        return;
      }
      if (session.result || session.processing) {
        res.status(409).json({ error: "This upload is no longer accepting chunks." });
        return;
      }
      const chunkIndex = Number(req.params.chunkIndex);
      if (!Number.isSafeInteger(chunkIndex) || chunkIndex !== session.nextChunkIndex) {
        res.status(409).json({ error: "Upload chunks must be sent in order." });
        return;
      }
      if (req.headers["content-type"]?.split(";")[0] !== "application/octet-stream") {
        res.status(400).json({ error: "Upload chunks as application/octet-stream." });
        return;
      }
      const expectedBytes = Math.min(
        UPLOAD_CHUNK_BYTES,
        session.sizeBytes - session.receivedBytes,
      );
      if (expectedBytes <= 0) {
        res.status(409).json({ error: "All upload chunks have already been received." });
        return;
      }
      const chunk = await readRequest(
        req,
        UPLOAD_CHUNK_BYTES,
        "An upload chunk is larger than the 8 MB chunk limit.",
      );
      if (chunk.length !== expectedBytes) {
        res.status(400).json({ error: "Upload chunk size does not match the expected size." });
        return;
      }
      await fs.writeFile(path.join(session.chunksDir, `${chunkIndex}.part`), chunk, {
        flag: "wx",
      });
      session.receivedBytes += chunk.length;
      session.nextChunkIndex += 1;
      session.updatedAt = Date.now();
      res.json({ receivedBytes: session.receivedBytes });
    } catch (error) {
      const message = error instanceof Error ? error.message : "Could not store the upload chunk.";
      res.status(message.includes("limit") ? 413 : 400).json({ error: message });
    }
  },
);

router.post(
  "/process/uploads/:uploadId/complete",
  async (req, res: Response) => {
    const session = await getUploadSession(req.params.uploadId);
    if (!session) {
      res.status(404).json({ error: "Upload session not found. Start the upload again." });
      return;
    }
    if (session.processing) {
      res.status(409).json({ error: "This video is already being processed." });
      return;
    }
    if (session.result) {
      res.json(session.result);
      return;
    }
    if (session.receivedBytes !== session.sizeBytes) {
      res.status(400).json({ error: "The upload is incomplete; send all chunks first." });
      return;
    }

    session.processing = true;
    try {
      await assembleUpload(session);
      await fs.rm(session.chunksDir, { recursive: true, force: true });
      const result = await runWorker(session.sourcePath, session.outputPath, session.fields);
      await fs.rm(session.sourcePath, { force: true });
      session.result = {
        ...result,
        fileName: `${path.basename(session.fileName, path.extname(session.fileName))}_video.optimizemethod.mp4`,
        mimeType: "video/mp4",
        downloadUrl: `/api/process/uploads/${session.id}/result`,
      };
      session.updatedAt = Date.now();
      res.json(session.result);
    } catch (error) {
      req.log.error({ err: error }, "Chunked video processing failed");
      const message =
        error instanceof Error ? error.message : "Video processing failed.";
      res.status(500).json({ error: message });
    } finally {
      session.processing = false;
      session.updatedAt = Date.now();
    }
  },
);

router.get(
  "/process/uploads/:uploadId/result",
  async (req, res: Response) => {
    const session = await getUploadSession(req.params.uploadId);
    if (!session?.result) {
      res.status(404).json({ error: "The processed video is not available." });
      return;
    }
    const fileName = String(session.result.fileName ?? "video.optimizemethod_output.mp4");
    res.download(session.outputPath, fileName, (error) => {
      if (error) {
        req.log.error({ err: error }, "Processed video download failed");
        if (!res.headersSent) {
          res.status(500).json({ error: "The processed video could not be downloaded." });
        }
        return;
      }
      void removeUploadSession(session).catch((cleanupError) => {
        req.log.error({ err: cleanupError }, "Temporary video cleanup failed");
      });
    });
  },
);

router.delete(
  "/process/uploads/:uploadId",
  async (req, res: Response) => {
    const session = await getUploadSession(req.params.uploadId);
    if (session) {
      if (session.processing) {
        res.status(409).json({ error: "A video cannot be removed while it is processing." });
        return;
      }
      await removeUploadSession(session);
    }
    res.status(204).end();
  },
);

export default router;