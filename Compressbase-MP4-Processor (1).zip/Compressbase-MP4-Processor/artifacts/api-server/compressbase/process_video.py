"""Run the uploaded video through the supplied video.optimizemethod pipeline."""

import argparse
import json
import os

import ffmpeg_wrapper as fw
import isobmff_patcher as iso


SPEC_PATH = os.path.join(os.path.dirname(__file__), "target_spec.json")
with open(SPEC_PATH, "r", encoding="utf-8") as spec_file:
    TARGET_SPEC = json.load(spec_file)


def level_label(level):
    if level in (None, "N/A"):
        return "—"
    try:
        value = float(level)
        return f"{value / 10:.1f}" if value >= 10 else str(value)
    except (TypeError, ValueError):
        return str(level)


def stream_summary(probe_data):
    video = fw.get_video_stream(probe_data)
    audio = fw.get_audio_streams(probe_data)

    if video is None:
        raise RuntimeError("The uploaded file does not contain a video stream.")

    video_bitrate = fw.get_video_bitrate(probe_data)
    video_summary = {
        "codec": video.get("codec_name", "unknown"),
        "profile": video.get("profile", "unknown"),
        "level": level_label(video.get("level")),
        "pixelFormat": video.get("pix_fmt", "unknown"),
        "bitrateKbps": round(video_bitrate / 1000, 1),
        "width": video.get("width"),
        "height": video.get("height"),
    }

    audio_summary = []
    for stream in audio:
        raw_bitrate = stream.get("bit_rate")
        bitrate = 0 if raw_bitrate in (None, "N/A") else int(raw_bitrate)
        sample_rate = stream.get("sample_rate")
        channels = stream.get("channels")
        audio_summary.append(
            {
                "codec": stream.get("codec_name", "unknown"),
                "sampleRate": int(sample_rate) if sample_rate not in (None, "N/A") else 0,
                "channels": int(channels) if channels not in (None, "N/A") else 0,
                "bitrateKbps": round(bitrate / 1000, 1),
            }
        )

    fmt = probe_data.get("format", {})
    tags = fmt.get("tags", {})
    return {
        "durationSeconds": round(fw.get_duration_seconds(probe_data), 3),
        "sizeBytes": int(fmt.get("size", 0) or 0),
        "video": video_summary,
        "audioTracks": audio_summary,
        "format": fmt.get("format_name"),
        "brands": tags.get("compatible_brands"),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--bitrate-multiplier", type=float, default=1.0)
    parser.add_argument("--audio-bitrate1", type=int, default=190)
    parser.add_argument("--audio-bitrate2", type=int, default=215)
    parser.add_argument("--preset", default="fast")
    parser.add_argument("--level", default="4.2")
    parser.add_argument("--comment", default="Patched by video.optimizemethod")
    args = parser.parse_args()

    source_probe = fw.probe(args.input)
    if not fw.get_audio_streams(source_probe):
        raise RuntimeError("The uploaded file must contain at least one audio track.")

    temp_path = args.output + ".encoded.mp4"
    try:
        fw.encode(
            input_path=args.input,
            output_path=temp_path,
            bitrate_multiplier=args.bitrate_multiplier,
            audio_bitrate1_kbps=args.audio_bitrate1,
            audio_bitrate2_kbps=args.audio_bitrate2,
            preset=args.preset,
            level=args.level,
            comment=args.comment,
        )
        iso.apply_isobmff_patches(
            input_path=temp_path,
            output_path=args.output,
            major_brand="isom",
            minor_version=512,
            compatible_brands=["isom", "iso2", "avc1", "mp41"],
            remove_creation_time=True,
            encoder="Lavf59.27.100",
            comment=args.comment,
        )
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)

    output_probe = fw.probe(args.output)
    issues = fw.validate_output(output_probe, TARGET_SPEC)
    result = {
        "source": stream_summary(source_probe),
        "output": stream_summary(output_probe),
        "validation": {"valid": not issues, "issues": issues},
        "durationSeconds": round(fw.get_duration_seconds(output_probe), 3),
        "sizeBytes": os.path.getsize(args.output),
    }
    print(json.dumps(result, separators=(",", ":")))


if __name__ == "__main__":
    main()