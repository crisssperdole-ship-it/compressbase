"""
compressbase_gui.py
-------------------
Compressbase Clip Patcher — Tkinter GUI
Batch-converts video files to H.264 Constrained Baseline + dual AAC,
applies ISOBMFF binary patches, and validates output.

Requirements: ffmpeg/ffprobe in PATH, Python 3.10+
"""

import json
import os
import queue
import shutil
import tempfile
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import ffmpeg_wrapper as fw
import isobmff_patcher as iso

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

SPEC_PATH = os.path.join(os.path.dirname(__file__), "target_spec.json")

try:
    with open(SPEC_PATH, "r", encoding="utf-8") as _f:
        TARGET_SPEC = json.load(_f)
except Exception:
    TARGET_SPEC = {}

# ---------------------------------------------------------------------------
# Worker thread messages
# ---------------------------------------------------------------------------

class Msg:
    LOG = "log"
    PROGRESS_FILE = "progress_file"     # (index, percent)
    PROGRESS_TOTAL = "progress_total"   # (done, total)
    FILE_DONE = "file_done"             # (index, success, summary)
    ALL_DONE = "all_done"
    ERROR = "error"                     # (index, message)


# ---------------------------------------------------------------------------
# Processing logic (runs in worker thread)
# ---------------------------------------------------------------------------

def process_file(
    index: int,
    input_path: str,
    output_dir: str,
    params: dict,
    msg_queue: queue.Queue,
):
    """Process a single file. Posts messages to msg_queue throughout."""

    def log(text: str):
        msg_queue.put((Msg.LOG, text))

    def prog(pct: float, line: str = ""):
        msg_queue.put((Msg.PROGRESS_FILE, (index, pct)))
        if line:
            log(f"  ffmpeg: {line}")

    basename = os.path.basename(input_path)
    stem, _ = os.path.splitext(basename)
    output_path = os.path.join(output_dir, stem + "_compressbase.mp4")

    log(f"\n{'='*60}")
    log(f"[{index+1}] Processing: {basename}")
    log(f"    Output : {output_path}")

    try:
        # --- Probe source ---
        log("  Probing source…")
        src_probe = fw.probe(input_path)
        log(fw.format_probe_summary(src_probe, "SOURCE"))

        # --- Encode to temp file ---
        tmp_fd, tmp_path = tempfile.mkstemp(suffix=".mp4", prefix="cb_tmp_")
        os.close(tmp_fd)

        log("  Encoding (ffmpeg)…")
        out_probe = fw.encode(
            input_path=input_path,
            output_path=tmp_path,
            bitrate_multiplier=params["bitrate_multiplier"],
            audio_bitrate1_kbps=params["audio_bitrate1"],
            audio_bitrate2_kbps=params["audio_bitrate2"],
            preset=params["preset"],
            level=params["level"],
            comment=params["comment"],
            progress_callback=prog,
        )

        # --- Binary ISOBMFF patches ---
        log("  Applying ISOBMFF binary patches…")
        iso.apply_isobmff_patches(
            input_path=tmp_path,
            output_path=output_path,
            major_brand="isom",
            minor_version=512,
            compatible_brands=["isom", "iso2", "avc1", "mp41"],
            remove_creation_time=True,
            encoder="Lavf59.27.100",
            comment=params["comment"],
        )
        os.remove(tmp_path)

        # --- Re-probe output ---
        log("  Probing output…")
        final_probe = fw.probe(output_path)
        log(fw.format_probe_summary(final_probe, "OUTPUT"))

        # --- Validate ---
        issues = fw.validate_output(final_probe, TARGET_SPEC)
        if issues:
            log("  ⚠ Validation issues:")
            for iss in issues:
                log(f"    • {iss}")
        else:
            log("  ✓ Validation passed — output matches target spec.")

        # Size comparison
        src_size = os.path.getsize(input_path)
        dst_size = os.path.getsize(output_path)
        log(
            f"  Size: {src_size/1024/1024:.2f} MB → {dst_size/1024/1024:.2f} MB "
            f"({dst_size/src_size*100:.0f}%)"
        )

        summary = (
            f"{stem}_compressbase.mp4 — "
            f"{dst_size/1024/1024:.1f} MB, "
            f"{'OK' if not issues else f'{len(issues)} issue(s)'}"
        )
        msg_queue.put((Msg.FILE_DONE, (index, True, summary)))

    except Exception as exc:
        log(f"  ✗ ERROR: {exc}")
        msg_queue.put((Msg.ERROR, (index, str(exc))))
        msg_queue.put((Msg.FILE_DONE, (index, False, f"FAILED: {exc}")))
        # Clean up temp if still exists
        try:
            if "tmp_path" in dir() and os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass


def batch_worker(files: list[str], output_dir: str, params: dict, msg_queue: queue.Queue):
    total = len(files)
    for i, path in enumerate(files):
        process_file(i, path, output_dir, params, msg_queue)
        msg_queue.put((Msg.PROGRESS_TOTAL, (i + 1, total)))
    msg_queue.put((Msg.ALL_DONE, None))


# ---------------------------------------------------------------------------
# Main GUI class
# ---------------------------------------------------------------------------

class CompressbaseApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Compressbase Clip Patcher")
        self.resizable(True, True)
        self.minsize(780, 560)
        self._files: list[str] = []
        self._output_dir: str = ""
        self._running = False
        self._msg_queue: queue.Queue = queue.Queue()
        self._build_ui()
        self._poll_queue()

    # -----------------------------------------------------------------------
    # UI construction
    # -----------------------------------------------------------------------

    def _build_ui(self):
        # Top: file list panel
        top = ttk.LabelFrame(self, text="Input Files", padding=6)
        top.pack(fill="both", expand=False, padx=8, pady=(8, 4))

        btn_row = ttk.Frame(top)
        btn_row.pack(fill="x", pady=(0, 4))
        ttk.Button(btn_row, text="Add Files…", command=self._add_files).pack(side="left", padx=2)
        ttk.Button(btn_row, text="Remove Selected", command=self._remove_selected).pack(side="left", padx=2)
        ttk.Button(btn_row, text="Clear All", command=self._clear_files).pack(side="left", padx=2)

        list_frame = ttk.Frame(top)
        list_frame.pack(fill="both", expand=True)
        scroll_y = ttk.Scrollbar(list_frame, orient="vertical")
        self._file_listbox = tk.Listbox(
            list_frame, height=6, selectmode="extended",
            yscrollcommand=scroll_y.set,
            font=("Consolas", 9),
        )
        scroll_y.config(command=self._file_listbox.yview)
        scroll_y.pack(side="right", fill="y")
        self._file_listbox.pack(side="left", fill="both", expand=True)

        # Middle: settings
        mid = ttk.LabelFrame(self, text="Encoding Settings", padding=6)
        mid.pack(fill="x", padx=8, pady=4)

        self._params = {}

        row0 = ttk.Frame(mid)
        row0.pack(fill="x", pady=2)
        self._make_param(row0, "Bitrate multiplier:", "bitrate_multiplier", "0.42",
                         tooltip="Target video bitrate = source × multiplier (e.g. 0.42 = 42%)")
        self._make_param(row0, "Preset:", "preset", "fast",
                         choices=["ultrafast", "superfast", "veryfast", "faster",
                                  "fast", "medium", "slow"],
                         tooltip="ffmpeg preset. 'fast' recommended for speed.")

        row1 = ttk.Frame(mid)
        row1.pack(fill="x", pady=2)
        self._make_param(row1, "H.264 Level:", "level", "4.2",
                         choices=["3.1", "3.2", "4.0", "4.1", "4.2"],
                         tooltip="H.264 level. 4.2 is the Compressbase target.")
        self._make_param(row1, "Audio1 kbps:", "audio_bitrate1", "190",
                         tooltip="Bitrate for audio track 1 in kbps.")

        row2 = ttk.Frame(mid)
        row2.pack(fill="x", pady=2)
        self._make_param(row2, "Audio2 kbps:", "audio_bitrate2", "215",
                         tooltip="Bitrate for audio track 2 in kbps.")

        row3 = ttk.Frame(mid)
        row3.pack(fill="x", pady=2)
        ttk.Label(row3, text="Comment tag:").pack(side="left", padx=4)
        self._params["comment"] = tk.StringVar(value="Patched by Compressbase")
        ttk.Entry(row3, textvariable=self._params["comment"], width=36).pack(side="left", padx=2)

        # Output dir
        out_row = ttk.Frame(mid)
        out_row.pack(fill="x", pady=4)
        ttk.Label(out_row, text="Output folder:").pack(side="left", padx=4)
        self._output_dir_var = tk.StringVar(value="")
        ttk.Entry(out_row, textvariable=self._output_dir_var, width=40).pack(side="left", padx=2, fill="x", expand=True)
        ttk.Button(out_row, text="Browse…", command=self._pick_output_dir).pack(side="left", padx=2)

        # Progress section
        prog_frame = ttk.LabelFrame(self, text="Progress", padding=6)
        prog_frame.pack(fill="x", padx=8, pady=4)

        self._current_file_label = ttk.Label(prog_frame, text="Idle", anchor="w")
        self._current_file_label.pack(fill="x")
        self._file_progress = ttk.Progressbar(prog_frame, orient="horizontal", mode="determinate", maximum=100)
        self._file_progress.pack(fill="x", pady=2)

        self._total_label = ttk.Label(prog_frame, text="Total: 0 / 0", anchor="w")
        self._total_label.pack(fill="x")
        self._total_progress = ttk.Progressbar(prog_frame, orient="horizontal", mode="determinate", maximum=100)
        self._total_progress.pack(fill="x", pady=2)

        # Action buttons
        btn_frame = ttk.Frame(self)
        btn_frame.pack(fill="x", padx=8, pady=4)
        self._start_btn = ttk.Button(btn_frame, text="▶ Start Batch", command=self._start_batch)
        self._start_btn.pack(side="left", padx=4)
        self._stop_btn = ttk.Button(btn_frame, text="■ Stop", command=self._stop_batch, state="disabled")
        self._stop_btn.pack(side="left", padx=4)

        # Log panel
        log_frame = ttk.LabelFrame(self, text="Log / ffprobe Output", padding=6)
        log_frame.pack(fill="both", expand=True, padx=8, pady=(0, 8))

        log_scroll_y = ttk.Scrollbar(log_frame, orient="vertical")
        log_scroll_x = ttk.Scrollbar(log_frame, orient="horizontal")
        self._log_text = tk.Text(
            log_frame, height=12, state="disabled", wrap="none",
            font=("Consolas", 8),
            yscrollcommand=log_scroll_y.set,
            xscrollcommand=log_scroll_x.set,
        )
        log_scroll_y.config(command=self._log_text.yview)
        log_scroll_x.config(command=self._log_text.xview)
        log_scroll_x.pack(side="bottom", fill="x")
        log_scroll_y.pack(side="right", fill="y")
        self._log_text.pack(side="left", fill="both", expand=True)

        clear_btn = ttk.Button(log_frame, text="Clear Log", command=self._clear_log)
        clear_btn.pack(side="bottom", anchor="w", pady=2)

        # Tag styles
        self._log_text.tag_config("ok", foreground="#00aa00")
        self._log_text.tag_config("warn", foreground="#cc7700")
        self._log_text.tag_config("err", foreground="#cc0000")
        self._log_text.tag_config("head", foreground="#0055cc", font=("Consolas", 8, "bold"))

        self._stop_flag = threading.Event()

    def _make_param(self, parent, label, key, default, tooltip="", choices=None):
        f = ttk.Frame(parent)
        f.pack(side="left", padx=8)
        ttk.Label(f, text=label).pack(side="left")
        var = tk.StringVar(value=default)
        self._params[key] = var
        if choices:
            w = ttk.Combobox(f, textvariable=var, values=choices, width=12, state="readonly")
        else:
            w = ttk.Entry(f, textvariable=var, width=8)
        w.pack(side="left", padx=2)

    # -----------------------------------------------------------------------
    # File management
    # -----------------------------------------------------------------------

    def _add_files(self):
        paths = filedialog.askopenfilenames(
            title="Select Video Files",
            filetypes=[("Video files", "*.mp4 *.mov *.mkv *.avi *.hevc *.ts *.m4v"), ("All files", "*.*")],
        )
        for p in paths:
            if p not in self._files:
                self._files.append(p)
                self._file_listbox.insert("end", os.path.basename(p))

    def _remove_selected(self):
        sel = list(self._file_listbox.curselection())
        for i in reversed(sel):
            self._file_listbox.delete(i)
            del self._files[i]

    def _clear_files(self):
        self._file_listbox.delete(0, "end")
        self._files.clear()

    def _pick_output_dir(self):
        d = filedialog.askdirectory(title="Select Output Folder")
        if d:
            self._output_dir_var.set(d)

    # -----------------------------------------------------------------------
    # Batch control
    # -----------------------------------------------------------------------

    def _collect_params(self) -> dict | None:
        try:
            p = {
                "bitrate_multiplier": float(self._params["bitrate_multiplier"].get()),
                "audio_bitrate1": int(self._params["audio_bitrate1"].get()),
                "audio_bitrate2": int(self._params["audio_bitrate2"].get()),
                "preset": self._params["preset"].get(),
                "level": self._params["level"].get(),
                "comment": self._params["comment"].get(),
            }
            return p
        except ValueError as e:
            messagebox.showerror("Invalid Parameter", str(e))
            return None

    def _start_batch(self):
        if not self._files:
            messagebox.showwarning("No Files", "Add at least one video file to process.")
            return

        output_dir = self._output_dir_var.get().strip()
        if not output_dir:
            # Default: same folder as first input file
            output_dir = os.path.dirname(self._files[0])
            self._output_dir_var.set(output_dir)

        if not os.path.isdir(output_dir):
            try:
                os.makedirs(output_dir, exist_ok=True)
            except Exception as e:
                messagebox.showerror("Output Folder", f"Cannot create output folder:\n{e}")
                return

        # Check ffmpeg
        try:
            fw.find_ffmpeg()
        except RuntimeError as e:
            messagebox.showerror("ffmpeg Not Found", str(e))
            return

        params = self._collect_params()
        if params is None:
            return

        self._running = True
        self._stop_flag.clear()
        self._start_btn.config(state="disabled")
        self._stop_btn.config(state="normal")
        self._file_progress["value"] = 0
        self._total_progress["value"] = 0
        self._total_label.config(text=f"Total: 0 / {len(self._files)}")

        files_copy = list(self._files)
        t = threading.Thread(
            target=batch_worker,
            args=(files_copy, output_dir, params, self._msg_queue),
            daemon=True,
        )
        t.start()

    def _stop_batch(self):
        self._stop_flag.set()
        self._log("⚠ Stop requested — waiting for current file to finish…", "warn")

    # -----------------------------------------------------------------------
    # Message queue polling (runs on main thread via after())
    # -----------------------------------------------------------------------

    def _poll_queue(self):
        try:
            while True:
                kind, data = self._msg_queue.get_nowait()
                self._handle_msg(kind, data)
        except queue.Empty:
            pass
        self.after(80, self._poll_queue)

    def _handle_msg(self, kind: str, data):
        if kind == Msg.LOG:
            tag = ""
            if "✓" in data or "OK" in data:
                tag = "ok"
            elif "⚠" in data or "issue" in data.lower():
                tag = "warn"
            elif "✗" in data or "ERROR" in data or "FAILED" in data:
                tag = "err"
            elif data.startswith("==="):
                tag = "head"
            self._log(data, tag)

        elif kind == Msg.PROGRESS_FILE:
            index, pct = data
            basename = os.path.basename(self._files[index]) if index < len(self._files) else ""
            self._current_file_label.config(text=f"File [{index+1}]: {basename} — {pct:.0f}%")
            self._file_progress["value"] = pct

        elif kind == Msg.PROGRESS_TOTAL:
            done, total = data
            self._total_label.config(text=f"Total: {done} / {total}")
            self._total_progress["value"] = done / total * 100 if total > 0 else 0

        elif kind == Msg.FILE_DONE:
            index, success, summary = data
            tag = "ok" if success else "err"
            self._log(f"  → {summary}", tag)

        elif kind == Msg.ALL_DONE:
            self._running = False
            self._start_btn.config(state="normal")
            self._stop_btn.config(state="disabled")
            self._current_file_label.config(text="Done.")
            self._file_progress["value"] = 100
            self._total_progress["value"] = 100
            self._log("\n✓ Batch complete!", "ok")
            messagebox.showinfo("Done", "Batch processing complete!")

        elif kind == Msg.ERROR:
            index, msg = data
            self._log(f"  ERROR [{index+1}]: {msg}", "err")

    # -----------------------------------------------------------------------
    # Log helpers
    # -----------------------------------------------------------------------

    def _log(self, text: str, tag: str = ""):
        self._log_text.config(state="normal")
        if tag:
            self._log_text.insert("end", text + "\n", tag)
        else:
            self._log_text.insert("end", text + "\n")
        self._log_text.see("end")
        self._log_text.config(state="disabled")

    def _clear_log(self):
        self._log_text.config(state="normal")
        self._log_text.delete("1.0", "end")
        self._log_text.config(state="disabled")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app = CompressbaseApp()
    app.mainloop()
