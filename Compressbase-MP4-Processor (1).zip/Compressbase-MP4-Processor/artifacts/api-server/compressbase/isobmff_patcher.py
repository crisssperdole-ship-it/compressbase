"""
isobmff_patcher.py
------------------
Recursive ISOBMFF box-walker + binary patch utilities.
Handles: ftyp rewrite, creation_time removal, metadata tag injection.
"""

import re
import struct
from typing import Optional


# ---------------------------------------------------------------------------
# Low-level box primitives
# ---------------------------------------------------------------------------

def read_box_header(data: bytes, offset: int):
    """Return (size, fourcc, header_len) at given offset, or None at EOF."""
    if offset + 8 > len(data):
        return None
    size = struct.unpack_from(">I", data, offset)[0]
    fourcc = data[offset + 4: offset + 8].decode("latin-1")
    header_len = 8
    if size == 1:
        if offset + 16 > len(data):
            return None
        size = struct.unpack_from(">Q", data, offset + 8)[0]
        header_len = 16
    elif size == 0:
        size = len(data) - offset  # box extends to EOF
    return size, fourcc, header_len


def iter_boxes(data: bytes, start: int = 0, end: Optional[int] = None):
    """Yield (offset, size, fourcc, header_len) for each box in range."""
    if end is None:
        end = len(data)
    offset = start
    while offset < end:
        result = read_box_header(data, offset)
        if result is None:
            break
        size, fourcc, header_len = result
        if size < header_len:
            break
        yield offset, size, fourcc, header_len
        offset += size


# ---------------------------------------------------------------------------
# ftyp rewrite
# ---------------------------------------------------------------------------

def build_ftyp(major_brand: str, minor_version: int, compatible_brands: list[str]) -> bytes:
    major = major_brand.encode("latin-1").ljust(4)[:4]
    mv = struct.pack(">I", minor_version)
    compat = b"".join(b.encode("latin-1").ljust(4)[:4] for b in compatible_brands)
    payload = major + mv + compat
    size = 8 + len(payload)
    return struct.pack(">I", size) + b"ftyp" + payload


def patch_ftyp(data: bytearray,
               major_brand: str = "isom",
               minor_version: int = 0,
               compatible_brands: list[str] = None) -> bytearray:
    if compatible_brands is None:
        compatible_brands = ["isom", "iso2", "avc1", "mp41"]

    for offset, size, fourcc, _ in iter_boxes(bytes(data)):
        if fourcc == "ftyp":
            new_ftyp = build_ftyp(major_brand, minor_version, compatible_brands)
            result = bytearray()
            result += data[:offset]
            result += new_ftyp
            result += data[offset + size:]
            return result
    # No ftyp found — prepend
    new_ftyp = build_ftyp(major_brand, minor_version, compatible_brands)
    return bytearray(new_ftyp) + data


# ---------------------------------------------------------------------------
# creation_time zeroing
# ---------------------------------------------------------------------------

CREATION_TIME_BOXES = {"mvhd", "tkhd", "mdhd"}


def _zero_creation_time_in_fullbox(data: bytearray, offset: int, fourcc: str):
    """Zero creation_time and modification_time in mvhd/tkhd/mdhd."""
    # fullbox: 8 bytes header + 1 version + 3 flags = 12
    box_start = offset
    result = read_box_header(bytes(data), offset)
    if result is None:
        return
    size, _, header_len = result
    full_offset = box_start + header_len
    if full_offset + 4 > len(data):
        return
    version = data[full_offset]
    # version 0: times are uint32 at +4 and +8 (relative to full_offset+4)
    # version 1: times are uint64 at +4 and +12
    times_offset = full_offset + 4  # skip version+flags (4 bytes)
    if version == 1:
        # uint64 creation_time, uint64 modification_time
        struct.pack_into(">Q", data, times_offset, 0)
        struct.pack_into(">Q", data, times_offset + 8, 0)
    else:
        # uint32 creation_time, uint32 modification_time
        struct.pack_into(">I", data, times_offset, 0)
        struct.pack_into(">I", data, times_offset + 4, 0)


def _walk_and_zero_times(data: bytearray, start: int, end: int):
    """Recursively walk boxes and zero creation/modification times."""
    for offset, size, fourcc, header_len in iter_boxes(bytes(data), start, end):
        if fourcc in CREATION_TIME_BOXES:
            _zero_creation_time_in_fullbox(data, offset, fourcc)
        # Recurse into container boxes
        if fourcc in ("moov", "trak", "mdia", "minf", "stbl", "udta", "edts",
                      "dinf", "meta", "ilst"):
            _walk_and_zero_times(data, offset + header_len, offset + size)


def zero_creation_times(data: bytearray) -> bytearray:
    """Zero all creation_time / modification_time fields in-place (returns same bytearray)."""
    _walk_and_zero_times(data, 0, len(data))
    return data


# ---------------------------------------------------------------------------
# udta / meta / keys+ilst removal helper
# ---------------------------------------------------------------------------

def _remove_box_in_range(data: bytearray, start: int, end: int, target_fourcc: str) -> bytearray:
    """Remove first occurrence of target_fourcc box within [start, end)."""
    raw = bytes(data)
    for offset, size, fourcc, _ in iter_boxes(raw, start, end):
        if fourcc == target_fourcc:
            result = bytearray()
            result += data[:offset]
            result += data[offset + size:]
            return result
    return data


def remove_udta(data: bytearray) -> bytearray:
    """Remove udta box from moov."""
    raw = bytes(data)
    for offset, size, fourcc, header_len in iter_boxes(raw):
        if fourcc == "moov":
            moov_start = offset + header_len
            moov_end = offset + size
            return _remove_box_in_range(data, moov_start, moov_end, "udta")
    return data


# ---------------------------------------------------------------------------
# Simple binary find/replace for encoder tag (from reference implementation)
# ---------------------------------------------------------------------------

_ENCODER_RE = re.compile(rb"Lavf\d{2}\.\d{1,3}\.\d{1,3}")


def fix_encoder_tag(data: bytearray, target: bytes = b"Lavf59.27.100") -> bytearray:
    """
    Simple binary find/replace for encoder tag.
    ffmpeg always writes its own version in format.tags.encoder (e.g., "Lavf6X...").
    The key: "LavfXX.YY.ZZZ" has exactly the same byte length as target
    "Lavf59.27.100" -> we can do a simple find/replace binary, WITHOUT
    changing the size of any atom. This completely avoids the conflict that
    kept breaking comment in previous iterations.
    """
    matches = list(_ENCODER_RE.finditer(data))
    if not matches:
        return data
    for m in matches:
        found = m.group(0)
        if found == target:
            continue
        if len(found) != len(target):
            # Different length -> can't do in-place patch without recalculating atom sizes
            # Skip (rare, but possible if ffmpeg version has different digit count)
            continue
        data[m.start():m.end()] = target
    return data


# ---------------------------------------------------------------------------
# Recursive ISOBMFF parser for handler_name patch (from reference implementation)
# ---------------------------------------------------------------------------

CONTAINER_TYPES = {
    b"moov", b"trak", b"mdia", b"minf", b"stbl", b"udta", b"edts", b"dinf",
}

HANDLER_NAMES = (b"VideoHandler", b"SoundHandler")


class Box:
    __slots__ = ("type", "children", "payload")

    def __init__(self, box_type: bytes):
        self.type = box_type
        self.children: list["Box"] | None = None  # set for container boxes
        self.payload: bytes | None = None          # set for leaf boxes

    def serialize(self) -> bytes:
        if self.children is not None:
            body = b"".join(c.serialize() for c in self.children)
        else:
            body = self.payload
        size = 8 + len(body)
        return struct.pack(">I4s", size, self.type) + body


def parse_boxes(data: bytes, start: int, end: int) -> list[Box]:
    boxes = []
    pos = start
    while pos < end:
        size, box_type = struct.unpack(">I4s", data[pos:pos + 8])
        header_len = 8
        if size == 1:
            # 64-bit extended size (rare) — read but treat simply
            size = struct.unpack(">Q", data[pos + 8:pos + 16])[0]
            header_len = 16
        if size == 0:
            size = end - pos  # box extends to end of parent
        box_start = pos + header_len
        box_end = pos + size
        b = Box(box_type)
        if box_type in CONTAINER_TYPES:
            b.children = parse_boxes(data, box_start, box_end)
        else:
            b.payload = data[box_start:box_end]
        boxes.append(b)
        pos = box_end
    return boxes


def patch_hdlr_box(b: Box) -> bool:
    """Insert pascal-length byte before handler name if not already there."""
    assert b.type == b"hdlr" and b.payload is not None
    payload = b.payload
    # hdlr structure: version(1)+flags(3) + pre_defined(4) + handler_type(4) + reserved(12) + name(...)
    fixed_header_len = 1 + 3 + 4 + 4 + 12
    name = payload[fixed_header_len:]
    name_stripped = name.rstrip(b"\x00")  # ffmpeg usually writes null terminator
    for hn in HANDLER_NAMES:
        if name_stripped == hn:  # simple name, no pascal prefix yet
            new_name = bytes([len(hn)]) + hn  # pascal string, no null terminator
            b.payload = payload[:fixed_header_len] + new_name
            return True
        if name_stripped == bytes([len(hn)]) + hn:
            return False  # already patched
    return False


def walk_and_patch(boxes: list[Box]) -> bool:
    changed = False
    for b in boxes:
        if b.type == b"hdlr":
            if patch_hdlr_box(b):
                changed = True
        elif b.children is not None:
            if walk_and_patch(b.children):
                changed = True
    return changed


def patch_handler_names(data: bytearray) -> bytearray:
    """
    Patch handler_name using recursive ISOBMFF parser.
    Inserts pascal-length byte (0x0C for 12-char names) before "VideoHandler"/"SoundHandler".
    """
    top_boxes = parse_boxes(bytes(data), 0, len(data))
    moov_before = find_box(top_boxes, b"moov")
    size_before = len(moov_before.serialize())
    changed = walk_and_patch(top_boxes)
    if changed:
        # Adding the Pascal-length byte grows `moov`. Since chunk offsets are
        # absolute file offsets, compensate before serializing or players may
        # seek into the wrong bytes and freeze on the first frame.
        size_after = len(find_box(top_boxes, b"moov").serialize())
        delta = size_after - size_before
        if delta:
            shift_all_chunk_offsets(top_boxes, delta)
        new_data = b"".join(b.serialize() for b in top_boxes)
        return bytearray(new_data)
    return data


# ---------------------------------------------------------------------------
# Inflate nb_frames on second audio track (x10) without adding real audio data
# From reference implementation
# ---------------------------------------------------------------------------

def _split_evenly(total: int, parts: int) -> list[int]:
    """Split 'total' into 'parts' integers as equal as possible, sum = total."""
    base = total // parts
    rem = total % parts
    return [base + 1] * rem + [base] * (parts - rem)


def _parse_stts(payload: bytes) -> list[tuple[int, int]]:
    entry_count = struct.unpack(">I", payload[4:8])[0]
    entries = []
    off = 8
    for _ in range(entry_count):
        cnt, delta = struct.unpack(">II", payload[off:off + 8])
        entries.append((cnt, delta))
        off += 8
    return entries


def _build_stts(entries: list[tuple[int, int]]) -> bytes:
    out = bytearray(struct.pack(">II", 0, len(entries)))
    for cnt, delta in entries:
        out += struct.pack(">II", cnt, delta)
    return bytes(out)


def _parse_stsz(payload: bytes) -> tuple[int, list[int]]:
    sample_size, sample_count = struct.unpack(">II", payload[4:12])
    if sample_size != 0:
        return sample_size, [sample_size] * sample_count  # all equal, no table
    sizes = list(struct.unpack(f">{sample_count}I", payload[12:12 + 4 * sample_count]))
    return 0, sizes


def _build_stsz(sizes: list[int]) -> bytes:
    out = bytearray(struct.pack(">III", 0, 0, len(sizes)))  # sample_size=0 (variable)
    out += struct.pack(f">{len(sizes)}I", *sizes)
    return bytes(out)


def _parse_stsc(payload: bytes) -> list[tuple[int, int, int]]:
    entry_count = struct.unpack(">I", payload[4:8])[0]
    entries = []
    off = 8
    for _ in range(entry_count):
        first_chunk, samples_per_chunk, sdi = struct.unpack(">III", payload[off:off + 12])
        entries.append((first_chunk, samples_per_chunk, sdi))
        off += 12
    return entries


def _build_stsc(entries: list[tuple[int, int, int]]) -> bytes:
    out = bytearray(struct.pack(">II", 0, len(entries)))
    for fc, spc, sdi in entries:
        out += struct.pack(">III", fc, spc, sdi)
    return bytes(out)


def find_box(boxes: list[Box], box_type: bytes) -> Box:
    return next(b for b in boxes if b.type == box_type)


def get_stbl_for_handler(boxes: list[Box], handler_type: bytes) -> "Box | None":
    for b in boxes:
        if b.type == b"trak":
            mdia = find_box(b.children, b"mdia")
            hdlr = find_box(mdia.children, b"hdlr")
            if hdlr.payload[8:12] == handler_type:
                minf = find_box(mdia.children, b"minf")
                return find_box(minf.children, b"stbl")
    return None


def inflate_second_audio_track(top_boxes: list[Box], multiplier: int = 10) -> bool:
    """Find second audio track (2nd 'soun') and inflate its nb_frames."""
    moov = find_box(top_boxes, b"moov")
    audio_traks = [
        b for b in moov.children
        if b.type == b"trak"
        and find_box(find_box(b.children, b"mdia").children, b"hdlr").payload[8:12] == b"soun"
    ]
    if len(audio_traks) < 2:
        return False
    trak2 = audio_traks[1]
    mdia = find_box(trak2.children, b"mdia")
    minf = find_box(mdia.children, b"minf")
    stbl = find_box(minf.children, b"stbl")

    stts_box = find_box(stbl.children, b"stts")
    stsz_box = find_box(stbl.children, b"stsz")
    stsc_box = find_box(stbl.children, b"stsc")
    stco_box = find_box(stbl.children, b"stco")

    stco_count = struct.unpack(">I", stco_box.payload[4:8])[0]
    _, sizes = _parse_stsz(stsz_box.payload)
    if stco_count != len(sizes):
        raise NotImplementedError(
            f"Unexpected layout (stco={stco_count} vs stsz={len(sizes)} samples); "
            "requires manual adaptation of inflate_second_audio_track function."
        )

    stts_entries = _parse_stts(stts_box.payload)
    deltas = []
    for cnt, delta in stts_entries:
        deltas.extend([delta] * cnt)
    if len(deltas) != len(sizes):
        raise NotImplementedError("stts and stsz don't have the same number of samples.")

    n = len(sizes)
    # Last chunk is usually a "leftover" (different duration) -> leave unchanged
    last_is_leftover = len(stts_entries) >= 2 and stts_entries[-1][0] == 1
    n_inflate = n - 1 if last_is_leftover else n

    new_sizes: list[int] = []
    new_deltas: list[int] = []
    for i in range(n_inflate):
        sub_sizes = [sizes[i]] + [0] * (multiplier - 1)
        sub_deltas = _split_evenly(deltas[i], multiplier)
        new_sizes.extend(sub_sizes)
        new_deltas.extend(sub_deltas)
    if last_is_leftover:
        new_sizes.append(sizes[-1])
        new_deltas.append(deltas[-1])

    # stsz: new size table
    stsz_box.payload = _build_stsz(new_sizes)

    # stts: compress consecutive equal sequences into entries (run-length)
    stts_entries_new = []
    cur_delta, cur_count = new_deltas[0], 0
    for d in new_deltas:
        if d == cur_delta:
            cur_count += 1
        else:
            stts_entries_new.append((cur_count, cur_delta))
            cur_delta, cur_count = d, 1
    stts_entries_new.append((cur_count, cur_delta))
    stts_box.payload = _build_stts(stts_entries_new)

    # stsc: first n_inflate chunks now have `multiplier` logical samples,
    # last (if leftover) remains with 1
    new_stsc_entries = [(1, multiplier, 1)]
    if last_is_leftover:
        new_stsc_entries.append((n_inflate + 1, 1, 1))
    stsc_box.payload = _build_stsc(new_stsc_entries)

    return True


def find_all_boxes_by_type(boxes: list[Box], box_type: bytes) -> list[Box]:
    found = []
    for b in boxes:
        if b.type == box_type:
            found.append(b)
        if b.children is not None:
            found.extend(find_all_boxes_by_type(b.children, box_type))
    return found


def shift_all_chunk_offsets(top_boxes: list[Box], delta: int) -> None:
    """Add 'delta' to all absolute offsets in stco/co64 across entire moov tree."""
    moov = find_box(top_boxes, b"moov")
    for stco in find_all_boxes_by_type(moov.children, b"stco"):
        entry_count = struct.unpack(">I", stco.payload[4:8])[0]
        offsets = list(struct.unpack(f">{entry_count}I", stco.payload[8:8 + 4 * entry_count]))
        offsets = [o + delta for o in offsets]
        stco.payload = struct.pack(">II", 0, entry_count) + struct.pack(f">{entry_count}I", *offsets)
    for co64 in find_all_boxes_by_type(moov.children, b"co64"):
        entry_count = struct.unpack(">I", co64.payload[4:8])[0]
        offsets = list(struct.unpack(f">{entry_count}Q", co64.payload[8:8 + 8 * entry_count]))
        offsets = [o + delta for o in offsets]
        co64.payload = struct.pack(">II", 0, entry_count) + struct.pack(f">{entry_count}Q", *offsets)


def inflate_audio2_nb_frames(data: bytearray, multiplier: int = 10) -> bytearray:
    """Inflate nb_frames on second audio track by patching stsz/stts/stsc."""
    top_boxes = parse_boxes(bytes(data), 0, len(data))
    moov_before = find_box(top_boxes, b"moov")
    size_before = len(moov_before.serialize())

    changed = inflate_second_audio_track(top_boxes, multiplier)
    if not changed:
        return data

    size_after = len(find_box(top_boxes, b"moov").serialize())
    delta = size_after - size_before
    if delta:
        shift_all_chunk_offsets(top_boxes, delta)

    new_data = b"".join(b.serialize() for b in top_boxes)
    return bytearray(new_data)


# ---------------------------------------------------------------------------
# Full patch pipeline (called after ffmpeg re-encode)
# ---------------------------------------------------------------------------

def apply_isobmff_patches(
    input_path: str,
    output_path: str,
    major_brand: str = "isom",
    minor_version: int = 512,
    compatible_brands: list[str] = None,
    remove_creation_time: bool = True,
    encoder: str = "Lavf59.27.100",
    comment: str = "Patched by Compressbase",
) -> None:
    """
    Apply binary ISOBMFF patches:
      1. Rewrite ftyp box with target brands
      2. Zero all creation_time / modification_time fields
      3. Fix encoder tag via binary find/replace (no udta manipulation)
      4. Patch handler names with pascal-length prefix
      5. Inflate nb_frames on second audio track (x10)
    """
    if compatible_brands is None:
        compatible_brands = ["isom", "iso2", "avc1", "mp41"]

    with open(input_path, "rb") as f:
        data = bytearray(f.read())

    # 1. Rewrite ftyp
    data = patch_ftyp(data, major_brand=major_brand, minor_version=minor_version,
                      compatible_brands=compatible_brands)

    # 2. Zero creation / modification times
    if remove_creation_time:
        data = zero_creation_times(data)

    # 3. Fix encoder tag via binary find/replace (no udta manipulation)
    data = fix_encoder_tag(data, target=encoder.encode("latin-1"))

    # 4. Patch handler names with pascal-length prefix
    data = patch_handler_names(data)

    # 5. Inflate nb_frames on second audio track (x10)
    data = inflate_audio2_nb_frames(data, multiplier=10)

    with open(output_path, "wb") as f:
        f.write(data)


# ---------------------------------------------------------------------------
# Debug / inspection helpers
# ---------------------------------------------------------------------------

def dump_boxes(data: bytes, start: int = 0, end: Optional[int] = None,
               depth: int = 0) -> list[str]:
    """Return a human-readable list of box names for inspection."""
    lines = []
    if end is None:
        end = len(data)
    CONTAINERS = {"moov", "trak", "mdia", "minf", "stbl", "udta", "edts",
                  "dinf", "meta", "ilst", "moof", "traf"}
    for offset, size, fourcc, header_len in iter_boxes(data, start, end):
        lines.append("  " * depth + f"[{fourcc}] offset={offset} size={size}")
        if fourcc in CONTAINERS:
            lines.extend(dump_boxes(data, offset + header_len, offset + size, depth + 1))
    return lines


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        with open(sys.argv[1], "rb") as f:
            d = f.read()
        for line in dump_boxes(d):
            print(line)
