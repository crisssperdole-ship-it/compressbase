"""
ffmpeg_wrapper.py
-----------------
Subprocess wrappers for ffmpeg and ffprobe.
Handles: probe, re-encode (H.264 CBL + dual AAC), progress parsing.
"""

import json
import os
import re
import subprocess
import shutil
from typing import Callable, Optional


# ---------------------------------------------------------------------------
# ffprobe helpers
# ---------------------------------------------------------------------------

def find_ffmpeg() -> tuple[str, str]:
    """Return (ffmpeg_path, ffprobe_path). Raises RuntimeError if not found."""
    ff = shutil.which("ffmpeg")
    fp = shutil.which("ffprobe")
    if not ff:
        raise RuntimeError(
            "ffmpeg not found in PATH. Install ffmpeg and make sure it is in PATH."
        )
    if not fp:
        raise RuntimeError(
            "ffprobe not found in PATH. Install ffmpeg (includes ffprobe) and make sure it is in PATH."
        )
    return ff, fp


def probe(file_path: str) -> dict:
    """Run ffprobe and return parsed JSON (format + streams)."""
    _, ffprobe_path = find_ffmpeg()
    cmd = [
        ffprobe_path,
        "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        "-show_streams",
        file_path,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"ffprobe failed:\n{result.stderr}")
    return json.loads(result.stdout)


def get_video_bitrate(probe_data: dict) -> int:
    """Return overall bitrate in bits/sec from probe data (falls back to format bitrate)."""
    # Try video stream first
    for s in probe_data.get("streams", []):
        if s.get("codec_type") == "video":
            br = s.get("bit_rate")
            if br and br != "N/A":
                return int(br)
    # Fall back to format
    br = probe_data.get("format", {}).get("bit_rate")
    if br and br != "N/A":
        return int(br)
    return 0


def get_video_stream(probe_data: dict) -> Optional[dict]:
    for s in probe_data.get("streams", []):
        if s.get("codec_type") == "video":
            return s
    return None


def get_audio_streams(probe_data: dict) -> list[dict]:
    return [s for s in probe_data.get("streams", []) if s.get("codec_type") == "audio"]


def get_duration_seconds(probe_data: dict) -> float:
    d = probe_data.get("format", {}).get("duration")
    if d:
        return float(d)
    return 0.0


# ---------------------------------------------------------------------------
# Encode pipeline
# ---------------------------------------------------------------------------

def build_encode_command(
    ffmpeg_path: str,
    input_path: str,
    output_path: str,
    target_video_bitrate_kbps: int,
    audio_bitrate1_kbps: int = 190,
    audio_bitrate2_kbps: int = 215,
    preset: str = "fast",
    level: str = "4.2",
    comment: str = "Patched by video.optimizemethod",
    encoder_tag: str = "Lavf59.27.100",
    video_encoder_tag: str = "Lavc59.37.100 libx264",
) -> list[str]:
    """
    Build ffmpeg command that:
      - Re-encodes video to H.264 Constrained Baseline L4.2 (profile set last, after codec init)
      - Creates two AAC-LC 48kHz stereo tracks via explicit filtergraph re-encode
        Track 1: normal frame size (~1024 samples), track 2: smaller frame size → more packets
      - Sets language=eng on both audio streams
      - Injects comment + encoder at format level, encoder tag on video stream
      - Strips all source metadata (creation_time, etc.)
    """
    # Convert level "4.2" → "42" for -level (ffmpeg accepts both, but integer is unambiguous)
    # Keep as-is; ffmpeg handles "4.2" fine for -level

    # Build filtergraph:
    #   [0:a:0] → resample 48kHz stereo → split into two branches
    #   branch 0: aresample (track 1, standard)
    #   branch 1: aresample (track 2, same signal, different encoder params)
    # Using split filter so both tracks re-encode from the same decoded PCM,
    # NOT a copy from the encoded track 1.
    filter_complex = (
        "[0:a:0]aresample=48000,aformat=sample_fmts=fltp:channel_layouts=stereo,"
        "asplit=2[aout0][aout1]"
    )

    cmd = [
        ffmpeg_path,
        "-y",                           # overwrite output
        "-i", input_path,

        # ---- filtergraph for dual audio ----
        "-filter_complex", filter_complex,

        # ---- video map + encode ----
        "-map", "0:v:0",
        "-c:v", "libx264",
        "-preset", preset,
        "-b:v", f"{target_video_bitrate_kbps}k",
        "-maxrate", f"{target_video_bitrate_kbps}k",
        "-bufsize", f"{target_video_bitrate_kbps * 2}k",
        "-pix_fmt", "yuv420p",
        # Profile and level - x264 baseline == Constrained Baseline
        "-profile:v", "baseline",
        "-level:v", level,
        # Use only nal-hrd=cbr - don't use other x264-params that can override profile/level
        "-x264-params", "nal-hrd=cbr",
        "-metadata:s:v:0", "language=eng",

        # ---- audio track 0 (from filtergraph branch 0) ----
        "-map", "[aout0]",
        "-c:a:0", "aac",
        "-b:a:0", f"{audio_bitrate1_kbps}k",
        # Standard AAC frame size (1024) — encoder default, no override needed
        "-disposition:a:0", "default",
        "-metadata:s:a:0", "language=eng",

        # ---- audio track 1 (from filtergraph branch 1) ----
        "-map", "[aout1]",
        "-c:a:1", "aac",
        "-b:a:1", f"{audio_bitrate2_kbps}k",
        "-disposition:a:1", "default",
        "-metadata:s:a:1", "language=eng",

        # ---- strip all source metadata ----
        "-map_metadata", "-1",

        # ---- format-level metadata (comment only; encoder will be patched) ----
        "-metadata", f"comment={comment}",

        # ---- video stream metadata ----
        "-metadata:s:v:0", f"encoder={video_encoder_tag}",

        # ---- muxer options ----
        "-movflags", "+faststart",
        "-movflags", "+write_colr",     # preserve colour info box
        "-brand", "isom",
        "-f", "mp4",
        output_path,
    ]
    return cmd


def encode(
    input_path: str,
    output_path: str,
    bitrate_multiplier: float = 1.0,
    audio_bitrate1_kbps: int = 190,
    audio_bitrate2_kbps: int = 215,
    preset: str = "fast",
    level: str = "4.2",
    comment: str = "Patched by video.optimizemethod",
    progress_callback: Optional[Callable[[float, str], None]] = None,
) -> dict:
    """
    Full encode pipeline.

    progress_callback(percent: float, line: str) is called for each ffmpeg
    stderr line; percent is 0–100 based on time progress.

    Returns probe dict of the output file.
    """
    ffmpeg_path, _ = find_ffmpeg()

    # --- Probe input ---
    src_probe = probe(input_path)
    src_bitrate = get_video_bitrate(src_probe)
    duration = get_duration_seconds(src_probe)

    if src_bitrate == 0:
        # Fallback: 13 Mbps
        target_kbps = 13_000
    else:
        target_kbps = max(500, int(src_bitrate * bitrate_multiplier / 1000))

    cmd = build_encode_command(
        ffmpeg_path=ffmpeg_path,
        input_path=input_path,
        output_path=output_path,
        target_video_bitrate_kbps=target_kbps,
        audio_bitrate1_kbps=audio_bitrate1_kbps,
        audio_bitrate2_kbps=audio_bitrate2_kbps,
        preset=preset,
        level=level,
        comment=comment,
    )

    # Run ffmpeg, stream stderr for progress
    process = subprocess.Popen(
        cmd,
        stderr=subprocess.PIPE,
        stdout=subprocess.DEVNULL,
        text=True,
        errors="replace",
    )

    time_re = re.compile(r"time=(\d+):(\d+):([\d.]+)")

    for line in process.stderr:
        line = line.rstrip()
        if progress_callback:
            percent = 0.0
            m = time_re.search(line)
            if m and duration > 0:
                h, mn, s = int(m.group(1)), int(m.group(2)), float(m.group(3))
                elapsed = h * 3600 + mn * 60 + s
                percent = min(99.0, elapsed / duration * 100)
            progress_callback(percent, line)

    process.wait()
    if process.returncode != 0:
        raise RuntimeError(f"ffmpeg encoding failed (exit {process.returncode})")

    if progress_callback:
        progress_callback(100.0, "Encoding complete.")

    return probe(output_path)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def validate_output(
    output_probe: dict,
    spec: dict,
) -> list[str]:
    """
    Compare output probe against target spec.
    Returns list of human-readable mismatch strings (empty = all good).
    """
    issues = []

    fmt = output_probe.get("format", {})
    fmt_tags = fmt.get("tags", {})

    # --- format checks ---
    spec_fmt = spec.get("format", {})

    if "major_brand" in spec_fmt:
        actual = fmt_tags.get("major_brand", fmt.get("major_brand", ""))
        if actual != spec_fmt["major_brand"]:
            issues.append(f"major_brand: expected '{spec_fmt['major_brand']}', got '{actual}'")

    if "compatible_brands" in spec_fmt:
        actual = fmt_tags.get("compatible_brands", fmt.get("compatible_brands", ""))
        if actual != spec_fmt["compatible_brands"]:
            issues.append(
                f"compatible_brands: expected '{spec_fmt['compatible_brands']}', got '{actual}'"
            )

    if spec_fmt.get("require_no_creation_time"):
        ct = fmt_tags.get("creation_time", "")
        if ct and ct not in ("", "1904-01-01T00:00:00.000000Z", "0001-01-01T00:00:00.000000Z"):
            issues.append(f"creation_time not removed from format tags (got '{ct}')")

    # --- stream checks ---
    spec_streams = spec.get("streams", {})
    video_stream = get_video_stream(output_probe)
    audio_streams = get_audio_streams(output_probe)

    if video_stream:
        sv = spec_streams.get("video", {})

        if "codec_name" in sv and video_stream.get("codec_name") != sv["codec_name"]:
            issues.append(
                f"video codec: expected '{sv['codec_name']}', got '{video_stream.get('codec_name')}'"
            )

        # profile check: must contain 'Constrained Baseline' or 'Baseline'
        if "profile" in sv:
            vp = video_stream.get("profile", "")
            if sv["profile"].lower() not in vp.lower():
                issues.append(f"video profile: expected to contain '{sv['profile']}', got '{vp}'")

        if "level" in sv:
            actual_level = video_stream.get("level")
            # level 4.2 = 42 in ffprobe
            expected = sv["level"]
            if isinstance(expected, str) and "." in expected:
                expected_int = int(expected.replace(".", ""))
            else:
                expected_int = int(expected)
            if actual_level != expected_int:
                issues.append(f"video level: expected {expected_int}, got {actual_level}")

        if "pix_fmt" in sv and video_stream.get("pix_fmt") != sv["pix_fmt"]:
            issues.append(
                f"pix_fmt: expected '{sv['pix_fmt']}', got '{video_stream.get('pix_fmt')}'"
            )

        # bitrate range
        br_range = sv.get("bitrate_range_kbps")
        if br_range:
            vbr = int(video_stream.get("bit_rate", 0)) // 1000
            if not (br_range[0] <= vbr <= br_range[1]):
                issues.append(
                    f"video bitrate: expected {br_range[0]}–{br_range[1]} kbps, got {vbr} kbps"
                )

    sa = spec_streams.get("audio", {})
    expected_audio_count = sa.get("count", 2)
    if len(audio_streams) != expected_audio_count:
        issues.append(
            f"audio tracks: expected {expected_audio_count}, got {len(audio_streams)}"
        )

    for i, astream in enumerate(audio_streams):
        if "codec_name" in sa and astream.get("codec_name") != sa["codec_name"]:
            issues.append(
                f"audio[{i}] codec: expected '{sa['codec_name']}', got '{astream.get('codec_name')}'"
            )
        if "sample_rate" in sa and astream.get("sample_rate") != str(sa["sample_rate"]):
            issues.append(
                f"audio[{i}] sample_rate: expected {sa['sample_rate']}, "
                f"got {astream.get('sample_rate')}"
            )

    return issues


# ---------------------------------------------------------------------------
# Human-readable comparison helper
# ---------------------------------------------------------------------------

def format_probe_summary(probe_data: dict, label: str = "") -> str:
    """Return a compact multi-line string summarizing key probe fields."""
    lines = []
    if label:
        lines.append(f"=== {label} ===")

    fmt = probe_data.get("format", {})
    tags = fmt.get("tags", {})
    lines.append(f"  Format   : {fmt.get('format_long_name', fmt.get('format_name', '?'))}")
    lines.append(f"  Duration : {float(fmt.get('duration', 0)):.2f}s")
    lines.append(f"  Bitrate  : {int(fmt.get('bit_rate', 0)) // 1000} kbps")
    lines.append(f"  Size     : {int(fmt.get('size', 0)) / 1024 / 1024:.2f} MB")
    lines.append(f"  major_brand : {tags.get('major_brand', tags.get('compatible_brands', '?'))}")
    lines.append(f"  comment     : {tags.get('comment', '-')}")
    lines.append(f"  encoder     : {tags.get('encoder', '-')}")

    for i, s in enumerate(probe_data.get("streams", [])):
        ct = s.get("codec_type", "?")
        cn = s.get("codec_name", "?")
        if ct == "video":
            lines.append(
                f"  Stream #{i} (video): {cn}, {s.get('profile','?')}, "
                f"L{s.get('level','?')}, {s.get('width')}x{s.get('height')}, "
                f"{s.get('r_frame_rate','?')} fps, "
                f"{int(s.get('bit_rate', 0)) // 1000} kbps"
            )
        elif ct == "audio":
            lines.append(
                f"  Stream #{i} (audio): {cn}, {s.get('sample_rate')} Hz, "
                f"{s.get('channel_layout','?')}, "
                f"{int(s.get('bit_rate', 0)) // 1000} kbps, "
                f"nb_frames={s.get('nb_frames','?')}"
            )
        stags = s.get("tags", {})
        if stags.get("creation_time"):
            lines.append(f"            creation_time: {stags['creation_time']}")
    return "\n".join(lines)
