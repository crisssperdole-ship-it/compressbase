import { type ChangeEvent, type DragEvent, type ReactNode, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useMutation } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import type { VideoProcessResult, VideoProbeSummary } from '@workspace/api-client-react';
import {
  AlertTriangle,
  Check,
  ChevronDown,
  Download,
  FileVideo,
  Gauge,
  Info,
  LoaderCircle,
  LockKeyhole,
  RotateCcw,
  Settings2,
  ShieldCheck,
  UploadCloud,
  X,
} from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

type ProcessingSettings = {
  bitrate_multiplier: number;
  audio_bitrate1: number;
  audio_bitrate2: number;
  preset: string;
  level: string;
  comment: string;
};

type UploadSessionResponse = {
  uploadId: string;
  chunkSizeBytes: number;
  chunkCount: number;
};

type UploadProgressResponse = {
  receivedBytes: number;
};

type ChunkedVideoResult = VideoProcessResult & { downloadUrl: string };

async function readApiResponse<T>(response: Response): Promise<T> {
  const text = await response.text();
  let payload: { error?: string } & Record<string, unknown>;
  try {
    payload = JSON.parse(text) as { error?: string } & Record<string, unknown>;
  } catch {
    throw new Error(
      response.ok
        ? 'The server returned an unreadable response.'
        : `Upload failed (HTTP ${response.status}).`,
    );
  }
  if (!response.ok) {
    throw new Error(payload.error || `Upload failed (HTTP ${response.status}).`);
  }
  return payload as T;
}

async function uploadAndProcessVideo(
  file: File,
  settings: ProcessingSettings,
  onProgress: (progress: number) => void,
): Promise<ChunkedVideoResult> {
  let uploadId: string | undefined;
  try {
    const session = await readApiResponse<UploadSessionResponse>(
      await fetch('/api/process/uploads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName: file.name,
          sizeBytes: file.size,
          contentType: file.type || 'video/mp4',
          settings,
        }),
      }),
    );
    uploadId = session.uploadId;

    for (let index = 0; index < session.chunkCount; index += 1) {
      const start = index * session.chunkSizeBytes;
      const end = Math.min(start + session.chunkSizeBytes, file.size);
      const progress = await readApiResponse<UploadProgressResponse>(
        await fetch(`/api/process/uploads/${encodeURIComponent(uploadId)}/chunks/${index}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/octet-stream' },
          body: file.slice(start, end),
        }),
      );
      if (progress.receivedBytes !== end) {
        throw new Error('The server did not receive the complete MP4 chunk.');
      }
      onProgress(Math.round((end / file.size) * 100));
    }

    return await readApiResponse<ChunkedVideoResult>(
      await fetch(`/api/process/uploads/${encodeURIComponent(uploadId)}/complete`, {
        method: 'POST',
      }),
    );
  } catch (error) {
    if (uploadId) {
      void fetch(`/api/process/uploads/${encodeURIComponent(uploadId)}`, {
        method: 'DELETE',
      }).catch(() => undefined);
    }
    throw error;
  }
}

function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [result, setResult] = useState<VideoProcessResult | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState('');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settings, setSettings] = useState({
    bitrate_multiplier: 1.0,
    audio_bitrate1: 190,
    audio_bitrate2: 215,
    preset: 'fast',
    level: '4.2',
    comment: 'Patched by video.optimizemethod',
  });
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const processVideo = useMutation({
    mutationFn: ({ file: sourceFile, settings: processingSettings }: {
      file: File;
      settings: ProcessingSettings;
    }) => uploadAndProcessVideo(sourceFile, processingSettings, setUploadProgress),
    onSuccess: (processed) => setResult(processed),
    onError: (mutationError) => {
      setError(mutationError.message || 'Processing failed. Check the file and try again.');
    },
  });

  const chooseFile = (candidate?: File) => {
    if (!candidate) return;
    if (candidate.type !== 'video/mp4' && !candidate.name.toLowerCase().endsWith('.mp4')) {
      setError('video.optimizemethod accepts MP4 files only. Choose an .mp4 video and try again.');
      setFile(null);
      return;
    }
    setError('');
    setResult(null);
    setFile(candidate);
  };

  const handleInput = (event: ChangeEvent<HTMLInputElement>) => chooseFile(event.target.files?.[0]);
  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragging(false);
    chooseFile(event.dataTransfer.files?.[0]);
  };
  const removeFile = () => {
    setFile(null);
    setResult(null);
    setError('');
    if (inputRef.current) inputRef.current.value = '';
  };
  const process = () => {
    if (!file || processVideo.isPending) return;
    setError('');
    setUploadProgress(0);
    processVideo.mutate({ file, settings });
  };
  const download = () => {
    if (!result) return;
    if (!result.downloadUrl) {
      setError('The processed MP4 download link is missing. Process the video again.');
      return;
    }
    const anchor = document.createElement('a');
    anchor.href = result.downloadUrl;
    anchor.click();
  };

  return (
    <main className="precision-grid min-h-[100dvh] overflow-hidden">
      <header className="mx-auto flex max-w-[1440px] items-center justify-between px-5 py-5 sm:px-8 lg:px-12">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-primary text-primary-foreground shadow-[0_0_24px_rgba(87,255,205,.18)]">
            <span className="mono text-sm font-medium">cb</span>
          </div>
          <div>
            <div className="text-[15px] font-extrabold tracking-[-.02em]">video.optimizemethod</div>
            <div className="mono flex items-center gap-2 text-[9px] uppercase tracking-[.2em] text-muted-foreground">
              <span>MP4 processor</span>
              <a
                href="https://discord.gg/PVnsmpmbx"
                target="_blank"
                rel="noreferrer"
                aria-label="Join our Discord"
                className="text-muted-foreground transition-colors hover:text-primary"
              >
                <svg viewBox="0 0 24 24" aria-hidden="true" className="h-4 w-4">
                  <path
                    fill="currentColor"
                    d="M20.317 4.37a19.79 19.79 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.056 19.9 19.9 0 0 0 5.993 3.03.077.077 0 0 0 .084-.028c.462-.63.873-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.19 13.19 0 0 1-1.872-.892.077.077 0 0 1-.008-.128c.126-.094.252-.192.372-.291a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.099.246.197.373.291a.077.077 0 0 1-.006.128c-.598.35-1.22.647-1.873.892a.077.077 0 0 0-.04.107c.36.698.77 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.055c.5-5.177-.838-9.674-3.548-13.66a.061.061 0 0 0-.031-.028zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.166 1.096 2.157 2.419 0 1.334-.956 2.419-2.157 2.419zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.166 1.096 2.157 2.419 0 1.334-.956 2.419-2.157 2.419z"
                  />
                </svg>
              </a>
            </div>
          </div>
        </div>
        <div className="mono flex items-center gap-2 text-[10px] uppercase tracking-[.16em] text-muted-foreground">
          <span className="h-1.5 w-1.5 rounded-full bg-primary shadow-[0_0_10px_hsl(var(--primary))]" />
          local-first workflow
        </div>
      </header>

      <div className="mx-auto max-w-[1440px] px-5 pb-12 pt-9 sm:px-8 lg:px-12 lg:pt-14">
        <section className="animate-rise grid gap-10 lg:grid-cols-[minmax(0,1fr)_360px] lg:gap-20">
          <div className="max-w-[780px]">
            <div className="mono mb-5 flex items-center gap-2 text-[10px] font-medium uppercase tracking-[.2em] text-primary">
              <span className="h-px w-7 bg-primary" />
              deterministic media utility / 01
            </div>
            <h1 className="max-w-[700px] text-[clamp(2.8rem,7vw,6.4rem)] font-extrabold leading-[.91] tracking-[-.075em] text-foreground">
              Patch the file.<br /><span className="text-primary">Trust the output.</span>
            </h1>
            <p className="mt-7 max-w-[560px] text-[15px] leading-7 text-muted-foreground sm:text-[17px]">
              A focused MP4 pipeline for editors and developers. Drop one source, verify the target, and get a spec-compliant file back.
            </p>
          </div>
          <div className="hidden self-end lg:block">
            <div className="border-l border-border pl-5">
              <div className="mono text-[10px] uppercase tracking-[.15em] text-muted-foreground">target profile</div>
              <div className="mt-3 flex items-center gap-2 text-sm font-semibold text-foreground">
                <ShieldCheck className="h-4 w-4 text-primary" /> H.264 / dual AAC
              </div>
              <div className="mono mt-2 text-[11px] leading-5 text-muted-foreground">CONSTRAINED BASELINE · LEVEL 4.2<br />ISOBMFF PATCH + VALIDATION</div>
            </div>
          </div>
        </section>

        <div className="mt-12 grid items-start gap-5 lg:grid-cols-[minmax(0,1fr)_360px] lg:gap-20">
          <section className="animate-rise animate-rise-delay-1">
            <div className="mb-3 flex items-center justify-between">
              <div className="mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">01 / source upload</div>
              {file && <div className="mono text-[10px] text-primary">READY TO PROCESS</div>}
            </div>
            {!file ? (
              <div
                data-testid="dropzone-video"
                onDragOver={(event) => { event.preventDefault(); setIsDragging(true); }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                className={`group relative flex min-h-[280px] cursor-pointer flex-col items-center justify-center overflow-hidden rounded-2xl border border-dashed px-6 text-center transition-colors ${isDragging ? 'border-primary bg-primary/10' : 'border-border bg-card/70 hover:border-primary/60 hover:bg-card'}`}
                onClick={() => inputRef.current?.click()}
              >
                <input data-testid="input-video-file" ref={inputRef} type="file" accept="video/mp4,.mp4" className="hidden" onChange={handleInput} />
                <div className={`mb-5 flex h-14 w-14 items-center justify-center rounded-2xl border ${isDragging ? 'border-primary bg-primary/15 text-primary' : 'border-border bg-secondary text-muted-foreground group-hover:border-primary/60 group-hover:text-primary'}`}>
                  <UploadCloud className="h-6 w-6" />
                </div>
                <p className="text-sm font-bold text-foreground">Drop an MP4 here</p>
                <p className="mt-2 text-xs text-muted-foreground">or <span className="font-semibold text-primary">browse from your device</span></p>
                <div className="mono mt-8 flex items-center gap-2 text-[9px] uppercase tracking-[.16em] text-muted-foreground">
                  <LockKeyhole className="h-3 w-3" /> one file · mp4 only
                </div>
              </div>
            ) : (
              <div className="rounded-2xl border border-primary/35 bg-card p-5 shadow-[0_18px_50px_rgba(0,0,0,.16)] sm:p-6">
                <div className="flex items-start gap-4">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/12 text-primary">
                    <FileVideo className="h-6 w-6" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-bold text-foreground" data-testid="text-source-filename">{file.name}</div>
                    <div className="mono mt-1 text-[10px] text-muted-foreground">{formatBytes(file.size)} <span className="px-1 text-border">/</span> {file.type || 'video/mp4'}</div>
                  </div>
                  <button data-testid="button-remove-file" type="button" onClick={removeFile} aria-label="Remove file" className="rounded-lg p-2 text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive">
                    <X className="h-4 w-4" />
                  </button>
                </div>
                <div className="mt-5 flex flex-wrap gap-2">
                  <button data-testid="button-replace-file" type="button" onClick={() => inputRef.current?.click()} className="mono inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-[10px] uppercase tracking-[.1em] text-muted-foreground transition-colors hover:border-primary/60 hover:text-primary">
                    <RotateCcw className="h-3 w-3" /> Replace
                  </button>
                  <span className="mono inline-flex items-center gap-2 rounded-lg bg-primary/10 px-3 py-2 text-[10px] uppercase tracking-[.1em] text-primary">
                    <Check className="h-3 w-3" /> Valid MP4
                  </span>
                </div>
                <input ref={inputRef} data-testid="input-replace-file" type="file" accept="video/mp4,.mp4" className="hidden" onChange={handleInput} />
              </div>
            )}
            {error && (
              <div data-testid="status-error" className="mt-4 flex items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/8 p-4 text-sm text-destructive">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}
            {file && (
              <div className="mt-5">
                <button data-testid="button-process-video" type="button" disabled={processVideo.isPending} onClick={process} className="group flex w-full items-center justify-between rounded-xl bg-primary px-5 py-4 text-left text-sm font-extrabold text-primary-foreground transition-transform hover:-translate-y-0.5 disabled:cursor-wait disabled:opacity-70">
                  <span>{processVideo.isPending ? 'Processing source…' : result ? 'Process again' : 'Process MP4'}</span>
                  {processVideo.isPending ? <LoaderCircle className="h-5 w-5 animate-spin" /> : <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary-foreground/12 transition-transform group-hover:translate-x-1">→</span>}
                </button>
                {processVideo.isPending && (
                  <div data-testid="status-processing" className="mt-3 overflow-hidden rounded-lg border border-border bg-card px-4 py-3">
                    <div className="flex items-center justify-between">
                      <span className="mono text-[10px] uppercase tracking-[.14em] text-muted-foreground">
                        {uploadProgress < 100 ? 'Uploading MP4 chunks' : 'Encoding, patching, validating'}
                      </span>
                      <span className="mono text-[10px] text-primary">
                        {uploadProgress < 100 ? `${uploadProgress}%` : 'RUNNING'}
                      </span>
                    </div>
                    <div className="relative mt-3 h-1 overflow-hidden rounded-full bg-secondary"><div className="scan-line absolute inset-y-0 w-1/3" /></div>
                  </div>
                )}
              </div>
            )}
          </section>

          <aside className="animate-rise animate-rise-delay-2 rounded-2xl border border-border bg-card/80 p-5 sm:p-6">
            <div className="flex items-start justify-between">
              <div>
                <div className="mono text-[10px] uppercase tracking-[.18em] text-muted-foreground">02 / target contract</div>
                <h2 className="mt-2 text-lg font-extrabold tracking-[-.03em]">video.optimizemethod target</h2>
              </div>
              <div className="rounded-lg bg-primary/10 p-2 text-primary"><Gauge className="h-4 w-4" /></div>
            </div>
            <div className="mt-6 space-y-3">
              <SpecRow label="Video" value="H.264 · Constrained Baseline" />
              <SpecRow label="Level" value="4.2" />
              <SpecRow label="Pixel format" value="yuv420p" />
              <SpecRow label="Audio" value="2 × AAC · 48 kHz" />
              <SpecRow label="Brands" value="isom / iso2 / avc1 / mp41" />
              <SpecRow label="Metadata" value="creation_time removed" />
              <SpecRow label="Encoder" value="Lavf59.27.100" />
            </div>
            <button data-testid="button-toggle-settings" type="button" onClick={() => setSettingsOpen((open) => !open)} className="mt-6 flex w-full items-center justify-between border-t border-border pt-4 text-left text-xs font-bold text-muted-foreground transition-colors hover:text-foreground">
              <span className="flex items-center gap-2"><Settings2 className="h-3.5 w-3.5" /> Pipeline parameters</span>
              <ChevronDown className={`h-4 w-4 transition-transform ${settingsOpen ? 'rotate-180' : ''}`} />
            </button>
            {settingsOpen && (
              <div className="mt-4 space-y-3">
                <Field label="Bitrate multiplier"><input data-testid="input-bitrate-multiplier" type="number" step="0.01" min="0.01" value={settings.bitrate_multiplier} onChange={(event) => setSettings({ ...settings, bitrate_multiplier: Number(event.target.value) })} /></Field>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Audio 1 kbps"><input data-testid="input-audio-bitrate-1" type="number" value={settings.audio_bitrate1} onChange={(event) => setSettings({ ...settings, audio_bitrate1: Number(event.target.value) })} /></Field>
                  <Field label="Audio 2 kbps"><input data-testid="input-audio-bitrate-2" type="number" value={settings.audio_bitrate2} onChange={(event) => setSettings({ ...settings, audio_bitrate2: Number(event.target.value) })} /></Field>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <Field label="Preset"><select data-testid="select-preset" value={settings.preset} onChange={(event) => setSettings({ ...settings, preset: event.target.value })}><option value="fast">fast</option><option value="medium">medium</option><option value="slow">slow</option></select></Field>
                  <Field label="H.264 level"><select data-testid="select-level" value={settings.level} onChange={(event) => setSettings({ ...settings, level: event.target.value })}><option value="4.2">4.2</option></select></Field>
                </div>
                <Field label="Comment"><input data-testid="input-comment" value={settings.comment} onChange={(event) => setSettings({ ...settings, comment: event.target.value })} /></Field>
              </div>
            )}
            <div className="mt-6 flex items-start gap-2 rounded-lg bg-secondary/70 p-3 text-[11px] leading-5 text-muted-foreground">
              <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-accent" />
              The output is binary-patched after encoding, then checked against this contract before download.
            </div>
          </aside>
        </div>

        {result && (
          <section data-testid="section-result" className="animate-rise mt-14 border-t border-border pt-10">
            <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
              <div>
                <div className="mono text-[10px] uppercase tracking-[.18em] text-primary">03 / inspection report</div>
                <h2 className="mt-2 text-3xl font-extrabold tracking-[-.05em]">Output is ready.</h2>
                <p className="mt-2 text-sm text-muted-foreground">Source and patched output, side by side.</p>
              </div>
              <button data-testid="button-download-output" type="button" onClick={download} className="inline-flex items-center justify-center gap-2 rounded-xl bg-accent px-5 py-3 text-sm font-extrabold text-accent-foreground transition-transform hover:-translate-y-0.5">
                <Download className="h-4 w-4" /> Download patched MP4
              </button>
            </div>
            <div className="mt-7 grid gap-4 lg:grid-cols-2">
              <ProbeCard label="Source probe" probe={result.source} />
              <ProbeCard label="Patched output" probe={result.output} output />
            </div>
            <div className={`mt-4 flex flex-col gap-3 rounded-xl border p-4 sm:flex-row sm:items-center ${result.validation.valid ? 'border-primary/30 bg-primary/7' : 'border-destructive/30 bg-destructive/8'}`}>
              <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${result.validation.valid ? 'bg-primary text-primary-foreground' : 'bg-destructive text-destructive-foreground'}`}>
                {result.validation.valid ? <Check className="h-5 w-5" /> : <AlertTriangle className="h-5 w-5" />}
              </div>
              <div className="flex-1">
                <div data-testid="status-validation" className="text-sm font-extrabold">{result.validation.valid ? 'Validation passed' : 'Validation found issues'}</div>
                <div className="mt-1 text-xs text-muted-foreground">{result.validation.valid ? 'Every target constraint is present in the output.' : result.validation.issues.join(' · ')}</div>
              </div>
              <div className="mono text-[10px] uppercase tracking-[.12em] text-muted-foreground">{formatBytes(result.sizeBytes)} · {formatDuration(result.durationSeconds)}</div>
            </div>
          </section>
        )}
      </div>
      <footer className="mx-auto flex max-w-[1440px] items-center justify-between border-t border-border px-5 py-5 sm:px-8 lg:px-12">
        <span className="mono text-[9px] uppercase tracking-[.15em] text-muted-foreground">video.optimizemethod / processor</span>
        <span className="mono text-[9px] uppercase tracking-[.15em] text-muted-foreground">MP4 · H.264 · AAC</span>
      </footer>
    </main>
  );
}

function SpecRow({ label, value }: { label: string; value: string }) {
  return <div className="flex items-start justify-between gap-4 border-b border-border/70 pb-2 text-xs last:border-0 last:pb-0"><span className="text-muted-foreground">{label}</span><span className="mono text-right text-[10px] text-foreground">{value}</span></div>;
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block"><span className="mono mb-1.5 block text-[9px] uppercase tracking-[.1em] text-muted-foreground">{label}</span>{children}</label>;
}

function ProbeCard({ label, probe, output = false }: { label: string; probe: VideoProbeSummary; output?: boolean }) {
  return (
    <div className={`rounded-xl border p-5 ${output ? 'border-primary/25 bg-primary/[.035]' : 'border-border bg-card/50'}`}>
      <div className="flex items-center justify-between">
        <div className="mono text-[10px] uppercase tracking-[.16em] text-muted-foreground">{label}</div>
        {output && <span className="mono flex items-center gap-1 text-[9px] uppercase tracking-[.1em] text-primary"><Check className="h-3 w-3" /> patched</span>}
      </div>
      <div className="mt-5 grid grid-cols-2 gap-y-5 sm:grid-cols-4 lg:grid-cols-2">
        <Metric label="Duration" value={formatDuration(probe.durationSeconds)} />
        <Metric label="Size" value={formatBytes(probe.sizeBytes)} />
        <Metric label="Video" value={`${probe.video.codec} · ${probe.video.profile}`} />
        <Metric label="Frame size" value={probe.video.width && probe.video.height ? `${probe.video.width} × ${probe.video.height}` : '—'} />
        <Metric label="Pixel format" value={probe.video.pixelFormat} />
        <Metric label="Video rate" value={`${probe.video.bitrateKbps} kbps`} />
        <Metric label="Audio tracks" value={`${probe.audioTracks.length} tracks`} />
        <Metric label="Container" value={probe.brands || probe.format || 'MP4'} />
      </div>
      <div className="mt-5 border-t border-border pt-4">
        <div className="mono mb-2 text-[9px] uppercase tracking-[.12em] text-muted-foreground">Audio track matrix</div>
        <div className="space-y-1.5">
          {probe.audioTracks.map((track, index) => <div key={`${label}-track-${index}`} className="flex justify-between text-[11px]"><span className="text-muted-foreground">Track {index + 1} · {track.codec}</span><span className="mono text-[10px] text-foreground">{track.sampleRate / 1000} kHz · {track.channels} ch · {track.bitrateKbps} kbps</span></div>)}
          {!probe.audioTracks.length && <div className="text-xs text-muted-foreground">No audio tracks reported</div>}
        </div>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return <div><div className="mono text-[9px] uppercase tracking-[.1em] text-muted-foreground">{label}</div><div className="mt-1 truncate text-xs font-semibold text-foreground">{value}</div></div>;
}

function formatBytes(bytes: number) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const unit = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / 1024 ** unit).toFixed(unit === 0 ? 0 : 2)} ${units[unit]}`;
}

function formatDuration(seconds: number) {
  if (!Number.isFinite(seconds)) return '—';
  const minutes = Math.floor(seconds / 60);
  const remaining = Math.floor(seconds % 60).toString().padStart(2, '0');
  return `${minutes}:${remaining}`;
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
