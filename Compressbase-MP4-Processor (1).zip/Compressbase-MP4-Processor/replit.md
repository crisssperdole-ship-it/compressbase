# Compressbase MP4 Processor

Web app that processes uploaded MP4 files through the supplied Compressbase ffmpeg and ISOBMFF patch pipeline.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/compressbase` — responsive React/Vite processor workspace
- `artifacts/api-server/src/routes/process.ts` — multipart upload and processing API
- `artifacts/api-server/compressbase` — Python ffmpeg wrapper, ISOBMFF patcher, validation spec, and worker
- `lib/api-spec/openapi.yaml` — source of truth for generated process API types/hooks

## Architecture decisions

- Processing stays server-side so the browser can use the exact supplied Python/ffmpeg and binary patch behavior.
- Uploads are held in a temporary server directory and returned as a downloadable MP4; no media bytes are persisted.
- The web client uses the generated multipart mutation hook and displays the worker's source/output probe summaries and validation issues.

## Product

Users can drop or browse for one MP4, adjust the target parameters, run the Compressbase conversion, inspect source/output metadata, see validation status, and download the patched result.

## User preferences

The target behavior and defaults come from the attached Compressbase Python project.

## Gotchas

- The processing worker requires `ffmpeg`, `ffprobe`, and `python3` in PATH.
- The uploaded media must include both video and audio; the supplied pipeline creates two AAC outputs from the first audio stream.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
